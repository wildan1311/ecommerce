<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class id_update extends Model
{
    use HasFactory;
    public static $id = 'nol';
    public static $req = array();
}
